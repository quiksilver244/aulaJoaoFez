<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post">
  <label for="Numero">Numero:</label>
  <input type="text" id="Numero" name="Numero" required>
  <br>
  <label for="fk_Rifa_id">fk_Rifa_id:</label>
  <input type="fk_Rifa_id" id="fk_Rifa_id" name="fk_Rifa_id" required>
  <br>
  <label for="fk_Pedido_id">fk_Pedido_id:</label>
  <input type="text" id="fk_Pedido_id" name="fk_Pedido_id" required>
  <br>
  <label for="creation_time">creation_time:</label>
  <input type="text" id="creation_time" name="creation_time">
  <br>
  <label for="modification_time">modification_time:</label>
  <input type="text" id="modification_time" name="modification_time">
  <br>
  <input type="submit" value="Cadastrar">
</form>
    <?php
    require_once 'model/NumeroDAO.php';
    require_once 'model/Numero.php';
    
    // verifica se os dados foram enviados pelo formulário
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      // obtém os dados do formulário
        $numero = $_POST['Numero'];
        $fk_Rifa_id = $_POST['fk_Rifa_id'];
        $fk_Pedido_id = $_POST['fk_Pedido_id'];
        $creation_time = $_POST['creation_time'];
        $modification_time = $_POST['modification_time'];
    
      // cria um novo objeto Usuario com os dados do formulário
      $usuario = new Usuario(0, $numero, $fk_Rifa_id, $fk_Pedido_id, $creation_time, 'CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP');
    
      var_dump($numero);

      // cria um novo objeto UsuarioDAO e insere o novo usuário no banco de dados
      $NumeroDAO = new NumeroDAO();
      $numero = $numeroDAO->insert($numero);
      if($numero){
        var_dump($numero);
      }
      else{
        var_dump($numeroDAO->getErro());
      }         
      
    }

    // $usuarioDAO = new UsuarioDAO();
    // var_dump($usuarioDAO->selectByNome());
    ?>
</body>
</html>